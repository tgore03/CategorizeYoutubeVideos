

EE 525 - Project

Steps to Run the Program:
1. Extract the zip folder
2. Open the ClassiTube.py python in python IDE or any other IDE
3. Run the program. (Note: It will a long time for the first time)

Steps to reduce the running time in the further runs:
1. Comment the line number 405 in ClassiTube.py (in Main())
2. Now run the program as before.

The program stores the Data Transformation and model information in files and hence the short version read this stored information 
and trains the model on it. 
